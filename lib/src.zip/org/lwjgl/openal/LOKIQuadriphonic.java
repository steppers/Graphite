/*
 * Copyright LWJGL. All rights reserved.
 * License terms: http://lwjgl.org/license.php
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.openal;

/** bindings to AL_LOKI_quadriphonic extension. */
public final class LOKIQuadriphonic {

	/** AL_LOKI_quadriphonic tokens. */
	public static final int
		AL_FORMAT_QUAD8_LOKI  = 0x10004,
		AL_FORMAT_QUAD16_LOKI = 0x10005;

	private LOKIQuadriphonic() {}

}